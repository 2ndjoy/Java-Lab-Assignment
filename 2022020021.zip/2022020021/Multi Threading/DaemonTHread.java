class Mythread extends Thread{
    public void run() {
        for (int i=0;i<10;i++) {
            System.out.println(i+"Daemon thread");

            try {
                Thread.sleep(500);
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
    class DaemonTHread {


    public static void main(String[] args) throws Exception{
        Mythread mythread=new Mythread();
        mythread.setDaemon(true);
        mythread.start();
        for (int i=0;i<5;i++){
            System.out.println(i+"Main thread");
            Thread.sleep(500);
        }


    }
}
